from flask import Flask, render_template, g, request, jsonify
import sqlite3

app = Flask(__name__)
DATABASE = "library.db"

def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/plants", methods=["GET"])
def plants():
    db = get_db()

    family_id = request.args.get("family")
    category_id = request.args.get("category")
    habitat_id = request.args.get("habitat")

    query = """
        SELECT DISTINCT p.*, c.name AS category, f.name AS family
        FROM plants p
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN families f ON p.family_id = f.id
        LEFT JOIN plant_habitats ph ON p.id = ph.plant_id
        LEFT JOIN habitats h ON ph.habitat_id = h.id
        WHERE 1 = 1
    """
    params = []

    if family_id:
        query += " AND f.id = ?"
        params.append(family_id)
    if category_id:
        query += " AND c.id = ?"
        params.append(category_id)
    if habitat_id:
        query += " AND h.id = ?"
        params.append(habitat_id)

    plants = db.execute(query, params).fetchall()

    families = db.execute("SELECT id, name FROM families").fetchall()
    categories = db.execute("SELECT DISTINCT c.id, c.name, c.family_id FROM categories c JOIN plants p ON p.category_id = c.id").fetchall()
    habitats = db.execute("SELECT id, name FROM habitats").fetchall()

    return render_template(
        "plants.html",
        plants=plants,
        families=families,
        categories=categories,  # Kategorijas būs pieejamas HTML
        habitats=habitats,
        selected_family=family_id,
        selected_category=category_id,
        selected_habitat=habitat_id,
    )

@app.route("/get_categories", methods=["GET"])
def get_categories():
    db = get_db()
    family_id = request.args.get("family")

    if family_id:
        categories = db.execute(
            """
            SELECT DISTINCT c.id, c.name
            FROM categories c
            JOIN plants p ON c.id = p.category_id
            WHERE p.family_id = ?
        """,
            (family_id,),
        ).fetchall()
    else:
        categories = db.execute(
            """
            SELECT DISTINCT c.id, c.name
            FROM categories c
            JOIN plants p ON c.id = p.category_id
        """
        ).fetchall()

    return jsonify([{"id": c["id"], "name": c["name"]} for c in categories])

@app.route("/get_habitats", methods=["GET"])
def get_habitats():
    db = get_db()
    family_id = request.args.get("family")
    category_id = request.args.get("category")

    query = """
        SELECT DISTINCT h.id, h.name
        FROM habitats h
        JOIN plant_habitats ph ON h.id = ph.habitat_id
        JOIN plants p ON ph.plant_id = p.id
        WHERE 1=1
    """
    params = []

    if family_id:
        query += " AND p.family_id = ?"
        params.append(family_id)
    if category_id:
        query += " AND p.category_id = ?"
        params.append(category_id)

    habitats = db.execute(query, params).fetchall()
    return jsonify([{"id": h["id"], "name": h["name"]} for h in habitats])

@app.route("/plants/<int:id>")
def plant_show(id):
    db = get_db()
    plant = db.execute(
        """
        SELECT p.*, c.name AS category, f.name AS family
        FROM plants p
        JOIN categories c ON p.category_id = c.id
        JOIN families f ON p.family_id = f.id
        WHERE p.id = ?
    """,
        (id,),
    ).fetchone()

    habitats = db.execute(
        """
        SELECT h.name FROM habitats h
        JOIN plant_habitats ph ON h.id = ph.habitat_id
        WHERE ph.plant_id = ?
    """,
        (id,),
    ).fetchall()

    return render_template("plants_show.html", plant=plant, habitats=habitats)

@app.route("/get_filters", methods=["GET"])
def get_filters():
    db = get_db()
    selected_family = request.args.get("family")
    selected_category = request.args.get("category")
    selected_habitat = request.args.get("habitat")

    query = """
        SELECT DISTINCT f.id AS family_id, f.name AS family,
                        c.id AS category_id, c.name AS category,
                        h.id AS habitat_id, h.name AS habitat
        FROM plants p
        LEFT JOIN families f ON p.family_id = f.id
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN plant_habitats ph ON ph.plant_id = p.id
        LEFT JOIN habitats h ON ph.habitat_id = h.id
        WHERE 1=1
    """
    params = []
    if selected_family:
        query += " AND f.id = ?"
        params.append(selected_family)
    if selected_category:
        query += " AND c.id = ?"
        params.append(selected_category)
    if selected_habitat:
        query += " AND h.id = ?"
        params.append(selected_habitat)

    rows = db.execute(query, params).fetchall()

    families = {}
    categories = {}
    habitats = {}

    for row in rows:
        if row["family_id"]:
            families[row["family_id"]] = row["family"]
        if row["category_id"]:
            categories[row["category_id"]] = row["category"]
        if row["habitat_id"]:
            habitats[row["habitat_id"]] = row["habitat"]

    return jsonify(
        {
            "families": [{"id": k, "name": v} for k, v in families.items()],
            "categories": [{"id": k, "name": v} for k, v in categories.items()],
            "habitats": [{"id": k, "name": v} for k, v in habitats.items()],
        }
    )


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)